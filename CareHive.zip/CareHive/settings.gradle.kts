pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}

dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.PREFER_SETTINGS) // ✅ Updated for flexibility
    repositories {
        google()
        mavenCentral()
        maven { url = uri("https://github.com/jitsi/jitsi-maven-repository/raw/master/releases") } // ✅ Jitsi Maven Repo
    }
}

rootProject.name = "CareHive"
include(":app")
