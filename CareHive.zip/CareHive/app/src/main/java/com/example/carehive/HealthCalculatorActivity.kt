package com.example.carehive

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.card.MaterialCardView

class HealthCalculatorActivity : AppCompatActivity() {

    private lateinit var bmiButton: MaterialCardView
    private lateinit var bmrButton: MaterialCardView
    private lateinit var pregnancyButton: MaterialCardView
    private lateinit var idealWeightButton: MaterialCardView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_health_calculator)

        bmiButton = findViewById(R.id.bmiButton)
        bmrButton = findViewById(R.id.bmrButton)
        pregnancyButton = findViewById(R.id.pregnancyButton)
        idealWeightButton = findViewById(R.id.idealWeightButton)

        bmiButton.setOnClickListener {
            val intent = Intent(this, BMICalculatorActivity::class.java)
            startActivity(intent)
        }

        bmrButton.setOnClickListener {
            val intent = Intent(this, BMRCalculatorActivity::class.java)
            startActivity(intent)
        }

        pregnancyButton.setOnClickListener {
            val intent = Intent(this, PregnancyWeightGainCalculatorActivity::class.java)
            startActivity(intent)
        }

        idealWeightButton.setOnClickListener {
            val intent = Intent(this, IdealWeightCalculatorActivity::class.java)
            startActivity(intent)
        }
    }
}
