package com.example.carehive

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.textfield.MaterialAutoCompleteTextView
import com.google.firebase.firestore.FirebaseFirestore
import java.util.*

class MedicineAlarmActivity : AppCompatActivity(), MedicineAlarmsAdapter.LoadAlarmsCallback {

    private lateinit var medicineNameEditText: EditText
    private lateinit var medicineTypeEditText: EditText
    private lateinit var doseEditText: EditText
    private lateinit var durationEditText: EditText
    private lateinit var alarmTimePicker: TimePicker
    private lateinit var timeOfDaySpinner: MaterialAutoCompleteTextView
    private lateinit var saveButton: Button
    private lateinit var viewAlarmButton: Button

    private lateinit var db: FirebaseFirestore

    private lateinit var recyclerView: RecyclerView
    private lateinit var adapter: MedicineAlarmsAdapter
    private var alarmsList: MutableList<MedicineAlarm> = mutableListOf()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_medicine_alarm)

        db = FirebaseFirestore.getInstance()

        medicineNameEditText = findViewById(R.id.medicineNameEditText)
        medicineTypeEditText = findViewById(R.id.medicineTypeEditText)
        doseEditText = findViewById(R.id.doseEditText)
        durationEditText = findViewById(R.id.durationEditText)
        alarmTimePicker = findViewById(R.id.alarmTimePicker)
        timeOfDaySpinner = findViewById(R.id.timeOfDaySpinner)
        saveButton = findViewById(R.id.saveButton)
        viewAlarmButton = findViewById(R.id.viewAlarmButton)

        recyclerView = findViewById(R.id.recyclerView)
        adapter = MedicineAlarmsAdapter(this, alarmsList, this)
        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = adapter

        val timeOptions = arrayOf("Morning", "Afternoon", "Night")
        val timeOfDayAdapter = ArrayAdapter(this, android.R.layout.simple_dropdown_item_1line, timeOptions)
        timeOfDaySpinner.setAdapter(timeOfDayAdapter)

        saveButton.setOnClickListener {
            saveMedicineAlarm()
        }

        viewAlarmButton.setOnClickListener {
            val intent = Intent(this@MedicineAlarmActivity, AlarmListActivity::class.java)
            startActivity(intent)
        }

        loadAlarms()
    }

    override fun onResume() {
        super.onResume()
        loadAlarms()
    }

    override fun loadAlarms() {
        db.collection("medicine_alarms")
            .get()
            .addOnSuccessListener { documents ->
                alarmsList.clear()
                for (document in documents) {
                    val alarm = document.toObject(MedicineAlarm::class.java)
                    alarm.documentId = document.id
                    alarmsList.add(alarm)
                }
                adapter.submitList(alarmsList.toList())
            }
            .addOnFailureListener { exception ->
                Toast.makeText(this, "Error loading alarms: $exception", Toast.LENGTH_SHORT).show()
            }
    }

    private fun saveMedicineAlarm() {
        val medicineName = medicineNameEditText.text.toString().trim()
        val medicineType = medicineTypeEditText.text.toString().trim()
        val dose = doseEditText.text.toString().trim()
        val duration = durationEditText.text.toString().trim()
        val timeOfDay = timeOfDaySpinner.text.toString().trim()

        val hour = alarmTimePicker.hour
        val minute = alarmTimePicker.minute

        val formattedTime = String.format("%02d:%02d", hour, minute)

        if (medicineName.isNotEmpty() && medicineType.isNotEmpty()) {

            val alarm = MedicineAlarm(
                medicine_name = medicineName,
                medicine_type = medicineType,
                dose = dose,
                duration = duration,
                alarm_time = formattedTime,
                time_of_day = timeOfDay
            )

            db.collection("medicine_alarms")
                .add(alarm)
                .addOnSuccessListener { documentReference ->
                    val alarmId = documentReference.id
                    scheduleAlarm(hour, minute, alarmId)
                    Toast.makeText(this, "Medicine Alarm Saved!", Toast.LENGTH_SHORT).show()
                    Log.d("Firebase", "Alarm saved successfully with ID: $alarmId")

                    // Clear input fields after save
                    medicineNameEditText.text.clear()
                    medicineTypeEditText.text.clear()
                    doseEditText.text.clear()
                    durationEditText.text.clear()

                    loadAlarms()
                }
                .addOnFailureListener { exception ->
                    Toast.makeText(this, "Error saving alarm: ${exception.message}", Toast.LENGTH_SHORT).show()
                    Log.e("Firebase", "Error saving alarm: ${exception.message}")
                }
        } else {
            Toast.makeText(this, "Please enter medicine name and type", Toast.LENGTH_SHORT).show()
        }
    }

    private fun scheduleAlarm(hour: Int, minute: Int, alarmId: String) {
        val calendar = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, hour)
            set(Calendar.MINUTE, minute)
            set(Calendar.SECOND, 0)
            if (before(Calendar.getInstance())) {
                add(Calendar.DATE, 1)
            }
        }

        Log.d("AlarmManager", "Alarm set for: ${calendar.time}, ID: $alarmId")

        val alarmManager = getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val intent = Intent(this, AlarmReceiver::class.java).apply {
            putExtra("ALARM_ID", alarmId)
        }
        val pendingIntent = PendingIntent.getBroadcast(
            this,
            alarmId.hashCode(),
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        alarmManager.setExact(AlarmManager.RTC_WAKEUP, calendar.timeInMillis, pendingIntent)
    }
}
//MedicineAlarmActivity ব্যবহারকারীকে ওষুধ খাওয়ার জন্য নির্দিষ্ট সময় অনুযায়ী অ্যালার্ম সেট ও সংরক্ষণ করতে সাহায্য করে। এটি Firestore-এ অ্যালার্ম সংরক্ষণ করে এবং Android AlarmManager দিয়ে নির্ধারিত সময়ের জন্য অ্যালার্ম চালু করে। ইউজার পূর্বের অ্যালার্মও দেখতে পারে এবং RecyclerView তে প্রদর্শিত হয়।