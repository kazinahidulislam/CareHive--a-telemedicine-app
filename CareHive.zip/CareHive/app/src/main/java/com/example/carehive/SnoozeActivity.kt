package com.example.carehive

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.SystemClock
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.example.carehive.databinding.ActivitySnoozeBinding
import com.google.android.material.button.MaterialButton
import com.google.firebase.firestore.FirebaseFirestore
import java.util.Calendar

class SnoozeActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySnoozeBinding
    private lateinit var alarmManager: AlarmManager
    private lateinit var db: FirebaseFirestore
    private var alarmId: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySnoozeBinding.inflate(layoutInflater)
        setContentView(binding.root)

        alarmManager = getSystemService(Context.ALARM_SERVICE) as AlarmManager
        db = FirebaseFirestore.getInstance()

        alarmId = intent.getStringExtra("ALARM_ID")

        setupClickListeners()
    }

    private fun setupClickListeners() {
        binding.snoozeButton.setOnClickListener { handleSnooze() }
        binding.skipButton.setOnClickListener { showSkipConfirmation() }
        binding.doneButton.setOnClickListener { showDoneConfirmation() }
    }

    private fun handleSnooze() {
        try {
            val calendar = Calendar.getInstance().apply {
                timeInMillis = SystemClock.elapsedRealtime()
                add(Calendar.MINUTE, 5)
            }

            val intent = Intent(this, AlarmReceiver::class.java).apply {
                putExtra("ALARM_ID", alarmId)
            }
            val pendingIntent = PendingIntent.getBroadcast(
                this,
                alarmId?.hashCode() ?: 0,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )

            alarmManager.setExact(
                AlarmManager.ELAPSED_REALTIME_WAKEUP,
                calendar.timeInMillis,
                pendingIntent
            )

            alarmId?.let { id ->
                db.collection("medicine_alarms").document(id)
                    .update("status", "snoozed")
            }

            showToast("Alarm snoozed for 5 minutes")
            finishWithAnimation()
        } catch (e: SecurityException) {
            showToast("Alarm permission required!")
        }
    }

    private fun showSkipConfirmation() {
        AlertDialog.Builder(this)
            .setTitle("Skip Alarm")
            .setMessage("Are you sure you want to skip this alarm?")
            .setPositiveButton("Yes") { _, _ -> handleSkip() }
            .setNegativeButton("No", null)
            .show()
    }

    private fun handleSkip() {
        alarmId?.let { id ->
            val intent = Intent(this, AlarmReceiver::class.java)
            val pendingIntent = PendingIntent.getBroadcast(
                this,
                id.hashCode(),
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            alarmManager.cancel(pendingIntent)
        }

        alarmId?.let { id ->
            db.collection("medicine_alarms").document(id)
                .update("status", "skipped")
        }

        showToast("Alarm skipped")
        finishWithAnimation()
    }

    private fun showDoneConfirmation() {
        AlertDialog.Builder(this)
            .setTitle("Complete Alarm")
            .setMessage("Mark this alarm as done?")
            .setPositiveButton("Yes") { _, _ -> handleDone() }
            .setNegativeButton("No", null)
            .show()
    }

    private fun handleDone() {
        alarmId?.let { id ->
            val intent = Intent(this, AlarmReceiver::class.java)
            val pendingIntent = PendingIntent.getBroadcast(
                this,
                id.hashCode(),
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            alarmManager.cancel(pendingIntent)
        }

        alarmId?.let { id ->
            db.collection("medicine_alarms").document(id)
                .update("status", "completed")
        }

        showToast("Alarm marked as done")
        finishWithAnimation()
    }

    private fun showToast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }

    private fun finishWithAnimation() {
        finish()
        overridePendingTransition(R.anim.slide_in, R.anim.slide_out)
    }
}
