package com.example.carehive

import android.app.DatePickerDialog
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.AutoCompleteTextView
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

class UserRegistrationActivity : AppCompatActivity() {

    private lateinit var auth: FirebaseAuth
    private lateinit var db: FirebaseFirestore

    private lateinit var nameEditText: EditText
    private lateinit var fatherNameEditText: EditText
    private lateinit var motherNameEditText: EditText
    private lateinit var currentAddressEditText: EditText
    private lateinit var permanentAddressEditText: EditText
    private lateinit var ageEditText: EditText
    private lateinit var birthdateEditText: EditText
    private lateinit var genderEditText: EditText
    private lateinit var bloodGroupEditText: EditText
    private lateinit var phoneNumberEditText: EditText
    private lateinit var emailEditText: EditText
    private lateinit var submitButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_user_registration)

        auth = FirebaseAuth.getInstance()
        db = FirebaseFirestore.getInstance()

        nameEditText = findViewById(R.id.nameEditText)
        fatherNameEditText = findViewById(R.id.fatherNameEditText)
        motherNameEditText = findViewById(R.id.motherNameEditText)
        currentAddressEditText = findViewById(R.id.currentAddressEditText)
        permanentAddressEditText = findViewById(R.id.permanentAddressEditText)
        ageEditText = findViewById(R.id.ageEditText)
        birthdateEditText = findViewById(R.id.birthdateEditText)
        genderEditText = findViewById(R.id.genderEditText)
        bloodGroupEditText = findViewById(R.id.bloodGroupEditText)
        phoneNumberEditText = findViewById(R.id.phoneNumberEditText)
        emailEditText = findViewById(R.id.emailEditText)
        submitButton = findViewById(R.id.submitButton)

        birthdateEditText.setOnClickListener {
            showDatePicker()
        }

        val genderAdapter = ArrayAdapter(
            this,
            android.R.layout.simple_dropdown_item_1line,
            listOf("Male", "Female", "Other")
        )
        (genderEditText as AutoCompleteTextView).setAdapter(genderAdapter)

        val bloodGroupAdapter = ArrayAdapter(
            this,
            android.R.layout.simple_dropdown_item_1line,
            listOf("A+", "A-", "B+", "B-", "O+", "O-", "AB+", "AB-")
        )
        (bloodGroupEditText as AutoCompleteTextView).setAdapter(bloodGroupAdapter)

        submitButton.setOnClickListener {
            registerUser()
        }
    }

    private fun showDatePicker() {
        val calendar = Calendar.getInstance()
        val year = calendar.get(Calendar.YEAR)
        val month = calendar.get(Calendar.MONTH)
        val day = calendar.get(Calendar.DAY_OF_MONTH)

        val datePickerDialog = DatePickerDialog(
            this,
            { _, selectedYear, selectedMonth, selectedDay ->
                val formattedDate = String.format(
                    Locale.getDefault(),
                    "%02d/%02d/%04d",
                    selectedDay,
                    selectedMonth + 1,
                    selectedYear
                )
                birthdateEditText.setText(formattedDate)

                calculateAge(selectedYear, selectedMonth, selectedDay)
            },
            year,
            month,
            day
        )
        datePickerDialog.show()
    }

    private fun calculateAge(year: Int, month: Int, day: Int) {
        val dob = Calendar.getInstance().apply {
            set(year, month, day)
        }
        val today = Calendar.getInstance()

        var age = today.get(Calendar.YEAR) - dob.get(Calendar.YEAR)

        if (today.get(Calendar.DAY_OF_YEAR) < dob.get(Calendar.DAY_OF_YEAR)) {
            age--
        }

        ageEditText.setText(age.toString())
    }

    private fun registerUser() {
        val name = nameEditText.text.toString().trim()
        val fatherName = fatherNameEditText.text.toString().trim()
        val motherName = motherNameEditText.text.toString().trim()
        val currentAddress = currentAddressEditText.text.toString().trim()
        val permanentAddress = permanentAddressEditText.text.toString().trim()
        val age = ageEditText.text.toString().trim()
        val birthdate = birthdateEditText.text.toString().trim()
        val gender = genderEditText.text.toString().trim()
        val bloodGroup = bloodGroupEditText.text.toString().trim()
        val phoneNumber = phoneNumberEditText.text.toString().trim()
        val email = emailEditText.text.toString().trim()

        if (name.isEmpty() || fatherName.isEmpty() || motherName.isEmpty() ||
            currentAddress.isEmpty() || permanentAddress.isEmpty() ||
            age.isEmpty() || birthdate.isEmpty() || gender.isEmpty() ||
            bloodGroup.isEmpty() || phoneNumber.isEmpty() || email.isEmpty()) {
            Toast.makeText(this, "All fields are required", Toast.LENGTH_SHORT).show()
            return
        }

        if (!isValidDate(birthdate)) {
            Toast.makeText(this, "Invalid birthdate format (DD/MM/YYYY)", Toast.LENGTH_SHORT).show()
            return
        }

        val user = hashMapOf(
            "name" to name,
            "fatherName" to fatherName,
            "motherName" to motherName,
            "currentAddress" to currentAddress,
            "permanentAddress" to permanentAddress,
            "age" to age.toInt(),
            "birthdate" to birthdate,
            "gender" to gender,
            "bloodGroup" to bloodGroup,
            "phoneNumber" to phoneNumber,
            "email" to email,
            "createdAt" to Calendar.getInstance().time
        )

        db.collection("users")
            .add(user)
            .addOnSuccessListener { documentReference ->
                Toast.makeText(this, "User registered successfully! ID: ${documentReference.id}", Toast.LENGTH_SHORT).show()
                finish()
            }
            .addOnFailureListener { e ->
                Toast.makeText(this, "Error registering user: ${e.message}", Toast.LENGTH_SHORT).show()
            }
    }

    private fun isValidDate(dateString: String): Boolean {
        val dateFormat = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())
        dateFormat.isLenient = false
        return try {
            dateFormat.parse(dateString)
            true
        } catch (e: Exception) {
            false
        }
    }
}
//UserRegistrationActivity হলো একটি রেজিস্ট্রেশন ফর্ম অ্যাক্টিভিটি যেখানে ইউজার নাম, জন্মতারিখ, ঠিকানা, ফোন, রক্তের গ্রুপসহ প্রয়োজনীয় তথ্য দিয়ে নিজেকে নিবন্ধন করতে পারে। জন্মতারিখ থেকে বয়স অটোমেটিক বের করে দেখানো হয় এবং সব তথ্য Firebase-এ সেভ করা হয়। এটি একটি সম্পূর্ণ ব্যবহারযোগ্য ইউজার ইনফরমেশন সিস্টেমের অংশ।
