package com.example.carehive

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.firestore.FirebaseFirestore

class MedicineAdapter(private val medicines: MutableList<Medicine>, val listener: MedicineActionListener) : RecyclerView.Adapter<MedicineAdapter.MedicineViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MedicineViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.medicine_item, parent, false)
        return MedicineViewHolder(view)
    }

    override fun onBindViewHolder(holder: MedicineViewHolder, position: Int) {
        val medicine = medicines[position]
        holder.bind(medicine)
    }

    override fun getItemCount(): Int = medicines.size

    inner class MedicineViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val medicineNameTextView: TextView = itemView.findViewById(R.id.medicineNameTextView)
        private val dosageTextView: TextView = itemView.findViewById(R.id.dosageTextView)
        private val expiryDateTextView: TextView = itemView.findViewById(R.id.expiryDateTextView)
        private val diseaseTextView: TextView = itemView.findViewById(R.id.diseaseTextView)
        private val updateButton: Button = itemView.findViewById(R.id.updateButton)
        private val deleteButton: Button = itemView.findViewById(R.id.deleteButton)

        fun bind(medicine: Medicine) {
            medicineNameTextView.text = medicine.medicineName
            dosageTextView.text = medicine.dosage
            expiryDateTextView.text = medicine.expiryDate
            diseaseTextView.text = medicine.disease

            updateButton.setOnClickListener {
                listener.onUpdateClick(medicine)
            }

            deleteButton.setOnClickListener {
                val db = FirebaseFirestore.getInstance()
                db.collection("own_medicines").document(medicine.id)
                    .delete()
                    .addOnSuccessListener {
                        Toast.makeText(itemView.context, "Medicine deleted", Toast.LENGTH_SHORT).show()
                        // Reload the list after deletion
                        (itemView.context as MedicineInventoryActivity).loadMedicines()
                    }
                    .addOnFailureListener {
                        Toast.makeText(itemView.context, "Error deleting medicine", Toast.LENGTH_SHORT).show()
                    }
            }
        }
    }

    interface MedicineActionListener {
        fun onUpdateClick(medicine: Medicine)
        fun onDeleteClick(medicine: Medicine)
    }
}
//MedicineAdapter ক্লাসটি CareHive অ্যাপে ওষুধের তালিকা RecyclerView-তে দেখায়। প্রতিটি ওষুধের পাশে আপডেট এবং ডিলিট বাটন থাকে। ডিলিট করলে Firestore থেকে ডেটা মুছে যায় এবং তালিকা রিফ্রেশ হয়। Update ক্লিক করলে Activity-তে ওষুধের তথ্য এডিট করার সুযোগ পাওয়া যায়।
