package com.example.carehive

import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.firestore.FirebaseFirestore

class DiseaseSearchActivity : AppCompatActivity() {

    private lateinit var db: FirebaseFirestore
    private lateinit var etDiseaseName: EditText
    private lateinit var tvDiseaseName: TextView
    private lateinit var tvMedicines: TextView
    private lateinit var tvTreatmentTips: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_disease_search)

        db = FirebaseFirestore.getInstance()

        etDiseaseName = findViewById(R.id.etDiseaseName)
        tvDiseaseName = findViewById(R.id.tvDiseaseName)
        tvMedicines = findViewById(R.id.tvMedicines)
        tvTreatmentTips = findViewById(R.id.tvTreatmentTips)

        findViewById<Button>(R.id.btnSearch).setOnClickListener {
            val diseaseName = etDiseaseName.text.toString().trim()
            if (diseaseName.isNotEmpty()) {
                searchDisease(diseaseName)
            } else {
                Toast.makeText(this, "Please enter a disease name", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun searchDisease(diseaseName: String) {
        db.collection("diseases")
            .whereEqualTo("diseaseName", diseaseName)
            .get()
            .addOnSuccessListener { documents ->
                if (documents.isEmpty) {
                    showError("Disease not found in database")
                    return@addOnSuccessListener
                }

                for (document in documents) {
                    val disease = document.toObject(Disease::class.java)
                    displayDiseaseInfo(disease)
                }
                Log.d("DiseaseSearch", "Found ${documents.size()} documents")

                for (document in documents) {
                    Log.d("DiseaseSearch", "Document data: ${document.data}")
                }

            }
            .addOnFailureListener { e ->
                showError("Failed to fetch data: ${e.message}")
            }
    }

    private fun displayDiseaseInfo(disease: Disease) {
        tvDiseaseName.text = disease.diseaseName
        tvMedicines.text = "Recommended Medicines:\n${disease.medicines.joinToString("\n")}"
        tvTreatmentTips.text = "Treatment Tips:\n• ${disease.treatmentTips.joinToString("\n• ")}"
    }

    private fun showError(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show()
        tvDiseaseName.text = ""
        tvMedicines.text = ""
        tvTreatmentTips.text = ""
    }

    data class Disease(
        val diseaseName: String = "",
        val medicines: List<String> = emptyList(),
        val treatmentTips: List<String> = emptyList()
    )
}
