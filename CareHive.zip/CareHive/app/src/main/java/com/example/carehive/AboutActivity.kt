package com.example.carehive

import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class AboutActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_about)

        supportActionBar?.title = "About CareHive"

        val versionTextView = findViewById<TextView>(R.id.versionTextView)
        val companyEmailTextView = findViewById<TextView>(R.id.companyEmailTextView)
        val companyPhoneTextView = findViewById<TextView>(R.id.companyPhoneTextView)

        versionTextView.text = "Version: 1.0.0"
        companyEmailTextView.text = "Email: nahidpola43@gmail.com"
        companyPhoneTextView.text = "Phone: +880 1911 684899"
    }
}
