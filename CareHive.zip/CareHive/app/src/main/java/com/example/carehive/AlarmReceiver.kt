package com.example.carehive

import android.Manifest
import android.annotation.SuppressLint
import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.RingtoneManager
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.util.Log
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat

class AlarmReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val alarmId = intent.getStringExtra("ALARM_ID")
        Log.d("AlarmReceiver", "Alarm triggered at: ${System.currentTimeMillis()}, ALARM_ID: $alarmId")

        val vibrator = context.getSystemService(Vibrator::class.java)
        vibrator?.vibrate(VibrationEffect.createOneShot(1000, VibrationEffect.DEFAULT_AMPLITUDE))

        val alarmUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
        val ringtone = RingtoneManager.getRingtone(context, alarmUri)
        ringtone.play()

        createNotification(context, alarmId)
    }

    private fun createNotificationChannel(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channelId = "medicine_alarm_channel"
            val channelName = "Medicine Alarm Notifications"
            val channelDescription = "Notifications for Medicine Alarm"
            val importance = NotificationManager.IMPORTANCE_HIGH

            val notificationChannel = NotificationChannel(channelId, channelName, importance).apply {
                description = channelDescription
            }

            val notificationManager = context.getSystemService(NotificationManager::class.java)
            notificationManager?.createNotificationChannel(notificationChannel)
        }
    }

    @SuppressLint("MissingPermission")
    private fun createNotification(context: Context, alarmId: String?) {
        val channelId = "medicine_alarm_channel"
        createNotificationChannel(context)

        val snoozeIntent = Intent(context, SnoozeActivity::class.java).apply {
            putExtra("ALARM_ID", alarmId)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        }

        val snoozePendingIntent = PendingIntent.getActivity(
            context,
            alarmId?.hashCode() ?: 0,
            snoozeIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notificationBuilder = NotificationCompat.Builder(context, channelId)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("Medicine Alarm")
            .setContentText("It's time to take your medicine!")
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(snoozePendingIntent)

        if (ActivityCompat.checkSelfPermission(
                context,
                Manifest.permission.POST_NOTIFICATIONS
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            Log.w("AlarmReceiver", "POST_NOTIFICATIONS permission not granted")
            return
        }

        val notificationManager = NotificationManagerCompat.from(context)
        notificationManager.notify(alarmId?.hashCode() ?: 1, notificationBuilder.build())
    }
}
//AlarmReceiver হল একটি BroadcastReceiver যা Medicine Alarm ট্রিগার হলে ভাইব্রেশন, রিংটোন ও একটি নোটিফিকেশন চালায়। এই নোটিফিকেশনের মাধ্যমে ইউজার SnoozeActivity খুলতে পারে। এটি Firebase-ভিত্তিক ALARM_ID ব্যবহার করে কাজ করে এবং Android 8+ এর জন্য notification channel তৈরি করে। এটি নিশ্চিত করে যে ইউজার সময়মতো ওষুধ খাওয়ার জন্য স্মরণপত্র পায়।