package com.example.carehive

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TimePicker
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.textfield.MaterialAutoCompleteTextView
import com.google.firebase.firestore.FirebaseFirestore
import android.widget.ArrayAdapter
import java.util.*

class EditMedicineAlarmActivity : AppCompatActivity() {

    private lateinit var medicineNameEditText: EditText
    private lateinit var medicineTypeEditText: EditText
    private lateinit var doseEditText: EditText
    private lateinit var durationEditText: EditText
    private lateinit var alarmTimePicker: TimePicker
    private lateinit var timeOfDaySpinner: MaterialAutoCompleteTextView
    private lateinit var saveButton: Button
    private lateinit var db: FirebaseFirestore
    private lateinit var documentId: String

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_edit_medicine_alarm)

        medicineNameEditText = findViewById(R.id.medicineNameEditText)
        medicineTypeEditText = findViewById(R.id.medicineTypeEditText)
        doseEditText = findViewById(R.id.doseEditText)
        durationEditText = findViewById(R.id.durationEditText)
        alarmTimePicker = findViewById(R.id.alarmTimePicker)
        timeOfDaySpinner = findViewById(R.id.timeOfDaySpinner)
        saveButton = findViewById(R.id.saveButton)

        db = FirebaseFirestore.getInstance()

        documentId = intent.getStringExtra("ALARM_ID") ?: ""
        if (documentId.isEmpty()) {
            Toast.makeText(this, "Invalid alarm ID", Toast.LENGTH_SHORT).show()
            finish()
            return
        }

        val timeOptions = arrayOf("Morning", "Afternoon", "Night")
        val adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, timeOptions)
        timeOfDaySpinner.setAdapter(adapter)

        loadAlarmData()

        saveButton.setOnClickListener {
            saveEditedAlarm()
        }
    }

    private fun loadAlarmData() {
        db.collection("medicine_alarms").document(documentId)
            .get()
            .addOnSuccessListener { document ->
                if (document.exists()) {
                    val medicineName = document.getString("medicine_name") ?: ""
                    val medicineType = document.getString("medicine_type") ?: ""
                    val dose = document.getString("dose") ?: ""
                    val duration = document.getString("duration") ?: ""
                    val alarmTime = document.getString("alarm_time") ?: "00:00"
                    val timeOfDay = document.getString("time_of_day") ?: "Morning"

                    medicineNameEditText.setText(medicineName)
                    medicineTypeEditText.setText(medicineType)
                    doseEditText.setText(dose)
                    durationEditText.setText(duration)

                    val timeParts = alarmTime.split(":")
                    if (timeParts.size >= 2) {
                        try {
                            alarmTimePicker.hour = timeParts[0].toInt()
                            alarmTimePicker.minute = timeParts[1].toInt()
                        } catch (e: NumberFormatException) {
                            alarmTimePicker.hour = 0
                            alarmTimePicker.minute = 0
                        }
                    }

                    timeOfDaySpinner.setText(timeOfDay, false)
                } else {
                    Toast.makeText(this, "No such alarm found", Toast.LENGTH_SHORT).show()
                    finish()
                }
            }
            .addOnFailureListener { exception ->
                Toast.makeText(this, "Error loading alarm data: ${exception.message}", Toast.LENGTH_SHORT).show()
                finish()
            }
    }

    private fun saveEditedAlarm() {
        val medicineName = medicineNameEditText.text.toString().trim()
        val medicineType = medicineTypeEditText.text.toString().trim()
        val dose = doseEditText.text.toString().trim()
        val duration = durationEditText.text.toString().trim()
        val timeOfDay = timeOfDaySpinner.text.toString().trim()
        val hour = alarmTimePicker.hour
        val minute = alarmTimePicker.minute

        if (medicineName.isNotEmpty() && medicineType.isNotEmpty()) {
            val updatedData = hashMapOf(
                "medicine_name" to medicineName,
                "medicine_type" to medicineType,
                "dose" to dose,
                "duration" to duration,
                "alarm_time" to String.format("%02d:%02d", hour, minute),
                "time_of_day" to timeOfDay
            )

            cancelAlarm(documentId)

            db.collection("medicine_alarms").document(documentId)
                .update(updatedData as Map<String, Any>)
                .addOnSuccessListener {
                    scheduleAlarm(hour, minute, documentId)
                    Toast.makeText(this, "Medicine Alarm Updated!", Toast.LENGTH_SHORT).show()
                    finish()
                }
                .addOnFailureListener { e ->
                    Toast.makeText(this, "Failed to update alarm: ${e.message}", Toast.LENGTH_SHORT).show()
                }
        } else {
            Toast.makeText(this, "Please enter medicine name and type", Toast.LENGTH_SHORT).show()
        }
    }

    private fun cancelAlarm(alarmId: String) {
        val alarmManager = getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val intent = Intent(this, AlarmReceiver::class.java)
        val pendingIntent = PendingIntent.getBroadcast(
            this,
            alarmId.hashCode(),
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        alarmManager.cancel(pendingIntent)
    }

    private fun scheduleAlarm(hour: Int, minute: Int, alarmId: String) {
        val calendar = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, hour)
            set(Calendar.MINUTE, minute)
            set(Calendar.SECOND, 0)
            if (before(Calendar.getInstance())) {
                add(Calendar.DATE, 1)
            }
        }

        val alarmManager = getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val intent = Intent(this, AlarmReceiver::class.java).apply {
            putExtra("ALARM_ID", alarmId)
        }
        val pendingIntent = PendingIntent.getBroadcast(
            this,
            alarmId.hashCode(),
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        alarmManager.setExact(AlarmManager.RTC_WAKEUP, calendar.timeInMillis, pendingIntent)
    }
}

//EditMedicineAlarmActivity ব্যবহারকারীদের পূর্বে নির্ধারিত ওষুধের অ্যালার্ম পরিবর্তন করার সুযোগ দেয়। এটি Firebase থেকে অ্যালার্ম ডেটা পড়ে UI-তে দেখায়, এবং ইউজার চাইলে পরিবর্তন করে পুনরায় Firebase-এ আপডেট করে এবং নতুন অ্যালার্ম সেট করে। এটি অ্যালার্ম বাতিল ও নতুনভাবে সেট করার জন্য Android-এর AlarmManager এবং PendingIntent ব্যবহার করে। Activity টি Medicine Alarm ফিচারকে আরও ইউজার-ফ্রেন্ডলি করে তোলে।