package com.example.carehive

import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import android.net.Uri
import android.widget.Toast


class DoctorAdapter(private val doctors: List<Doctor>) : RecyclerView.Adapter<DoctorAdapter.DoctorViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): DoctorViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.doctor_item, parent, false)
        return DoctorViewHolder(view)
    }

    override fun onBindViewHolder(holder: DoctorViewHolder, position: Int) {
        val doctor = doctors[position]
        holder.bind(doctor)
    }

    override fun getItemCount(): Int = doctors.size

    class DoctorViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val nameTextView: TextView = itemView.findViewById(R.id.doctorNameTextView)
        private val specializationTextView: TextView = itemView.findViewById(R.id.specializationTextView)
        private val contactTextView: TextView = itemView.findViewById(R.id.contactTextView)
        private val locationTextView: TextView = itemView.findViewById(R.id.locationTextView)
        private val callButton: Button = itemView.findViewById(R.id.callButton)
        private val feeTextView: TextView = itemView.findViewById(R.id.feeTextView)

        fun bind(doctor: Doctor) {
            nameTextView.text = doctor.name
            specializationTextView.text = doctor.specialization
            contactTextView.text = doctor.contact
            locationTextView.text = doctor.officeLocation

            val fee = doctor.consultationFee["generalConsultation"] ?: 0.0
            feeTextView.text = "Consultation Fee: $fee"

            callButton.setOnClickListener {
                val phoneNumber = doctor.contact
                if (phoneNumber.isNotEmpty()) {
                    val intent = Intent(Intent.ACTION_DIAL)
                    intent.data = Uri.parse("tel:$phoneNumber")
                    itemView.context.startActivity(intent)
                } else {
                    Toast.makeText(itemView.context, "Invalid phone number", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }
}

//DoctorAdapter একটি RecyclerView অ্যাডাপ্টার যা ডাক্তারের নাম, স্পেশালাইজেশন, কন্টাক্ট, লোকেশন ও কনসালটেশন ফি UI তে দেখায়। ব্যবহারকারী কল বাটনে ক্লিক করে সরাসরি ডাক্তারকে ফোন করতে পারেন। এটি CareHive অ্যাপে ডাক্তারের তালিকা দেখানোর জন্য একটি গুরুত্বপূর্ণ কম্পোনেন্ট।









