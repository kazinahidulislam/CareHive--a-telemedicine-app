package com.example.carehive

data class Doctor(
    val name: String = "",
    val specialization: String = "",
    val contact: String = "",
    val email: String = "",
    val officeLocation: String = "",
    val experience: String = "",
    var consultationFee: Map<String, Double> = mapOf()
)
