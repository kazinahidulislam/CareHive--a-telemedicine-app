package com.example.carehive

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.google.firebase.firestore.FirebaseFirestore

class AlarmViewModel : ViewModel() {

    private val db = FirebaseFirestore.getInstance()

    private val _alarms = MutableLiveData<List<MedicineAlarm>>()
    val alarms: LiveData<List<MedicineAlarm>> = _alarms

    fun loadAlarms() {
        db.collection("medicine_alarms")
            .get()
            .addOnSuccessListener { result ->
                val list = mutableListOf<MedicineAlarm>()
                for (document in result) {
                    val alarm = document.toObject(MedicineAlarm::class.java).apply {
                        documentId = document.id
                    }
                    list.add(alarm)
                }
                _alarms.value = list
            }
            .addOnFailureListener {
            }
    }

    fun deleteAlarm(documentId: String, onSuccess: () -> Unit, onFailure: (Exception) -> Unit) {
        db.collection("medicine_alarms").document(documentId)
            .delete()
            .addOnSuccessListener { onSuccess() }
            .addOnFailureListener { e -> onFailure(e) }
    }
}
//AlarmViewModel একটি ViewModel ক্লাস যা Firebase Firestore থেকে medicine_alarms লোড এবং ডিলিট করার কাজ করে। এটি LiveData ব্যবহার করে ডেটা UI-তে পাঠায় এবং Firestore অপারেশন সফল হলে callback দেয়। এটি UI এবং ডেটার মধ্যে একটি clean ও lifecycle-aware ব্রিজ তৈরি করে।