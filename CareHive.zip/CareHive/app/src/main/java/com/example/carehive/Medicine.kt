package com.example.carehive

data class Medicine(
    val id: String = "",
    val medicineName: String = "",
    val dosage: String = "",
    val expiryDate: String = "",
    val disease: String = ""
) {
    constructor() : this("", "", "", "", "")
}
//Medicine হল একটি ডেটা ক্লাস যা ওষুধের তথ্য সংরক্ষণ করে — যেমন নাম, ডোজ, মেয়াদ, রোগ ইত্যাদি। এটি CareHive অ্যাপে ওষুধ সংক্রান্ত তথ্য সংগ্রহ ও প্রদর্শনের জন্য ব্যবহৃত হয়।
