package com.example.carehive

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import com.mikhaellopez.circularprogressbar.CircularProgressBar
import com.google.android.material.card.MaterialCardView
import androidx.appcompat.app.AppCompatActivity

class BMICalculatorActivity : AppCompatActivity() {

    private lateinit var heightInput: EditText
    private lateinit var weightInput: EditText
    private lateinit var calculateButton: Button
    private lateinit var cardResult: MaterialCardView
    private lateinit var tvBMIValue: TextView
    private lateinit var tvBMICategory: TextView
    private lateinit var progressBar: CircularProgressBar

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_bmi_calculator)

        heightInput = findViewById(R.id.etHeight)
        weightInput = findViewById(R.id.etWeight)
        calculateButton = findViewById(R.id.btnCalculate)
        cardResult = findViewById(R.id.cardResult)
        tvBMIValue = findViewById(R.id.tvBMIValue)
        tvBMICategory = findViewById(R.id.tvBMICategory)
        progressBar = findViewById(R.id.progressBar)

        cardResult.visibility = android.view.View.GONE

        calculateButton.setOnClickListener {
            val height = heightInput.text.toString().toFloatOrNull()
            val weight = weightInput.text.toString().toFloatOrNull()

            if (height != null && weight != null) {
                val bmi = calculateBMI(weight, height)
                val healthStatus = getHealthStatus(bmi)

                tvBMIValue.text = bmi.toString()
                tvBMICategory.text = healthStatus

                val normalizedBMI = normalizeBMI(bmi)

                progressBar.setProgressWithAnimation(normalizedBMI, 1000)

                cardResult.visibility = android.view.View.VISIBLE
            } else {
                tvBMIValue.text = "Invalid Input"
                tvBMICategory.text = "Please enter valid values."
                cardResult.visibility = android.view.View.GONE
            }
        }
    }

    private fun calculateBMI(weight: Float, height: Float): Float {
        return weight / ((height / 100) * (height / 100))
    }

    private fun getHealthStatus(bmi: Float): String {
        return when {
            bmi < 18.5 -> "Underweight"
            bmi in 18.5..24.9 -> "Normal"
            bmi in 25.0..29.9 -> "Overweight"
            else -> "Obese"
        }
    }

    private fun normalizeBMI(bmi: Float): Float {
        return when {
            bmi < 10 -> 10f
            bmi > 40 -> 40f
            else -> bmi
        }
    }
}
