package com.example.carehive

import android.app.Notification
import android.app.NotificationManager
import android.content.Context
import androidx.core.app.NotificationCompat
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage

class MyFirebaseMessagingService : FirebaseMessagingService() {

    override fun onMessageReceived(remoteMessage: RemoteMessage) {
        if (remoteMessage.data.isNotEmpty()) {
            val healthTip = remoteMessage.data["healthTip"]
            sendNotification(healthTip)
        }
    }

    private fun sendNotification(healthTip: String?) {
        val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val notificationId = 1

        val builder = NotificationCompat.Builder(this, "HealthTipsChannel")
        .setSmallIcon(R.drawable.ic_health_tip)
            .setContentTitle("Daily Health Tip")
            .setContentText(healthTip ?: "No tip available today")
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)


        notificationManager.notify(notificationId, builder.build())
    }
}
