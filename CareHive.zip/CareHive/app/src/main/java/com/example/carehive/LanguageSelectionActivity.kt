package com.example.carehive

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class LanguageSelectionActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_language_selection)

        val btnEnglish: Button = findViewById(R.id.btnEnglish)
        val btnBangla: Button = findViewById(R.id.btnBangla)

        btnEnglish.setOnClickListener {
            setLanguage("en")
        }

        btnBangla.setOnClickListener {
            setLanguage("bn")
        }
    }

    private fun setLanguage(languageCode: String) {
        val sharedPreferences = getSharedPreferences("AppSettings", MODE_PRIVATE)
        val editor = sharedPreferences.edit()
        editor.putString("Language", languageCode)
        editor.apply()

        Toast.makeText(this, "Language changed to: $languageCode", Toast.LENGTH_SHORT).show()

        val intent = Intent(this, MainActivity::class.java)
        startActivity(intent)
        finish()
    }
}
//LanguageSelectionActivity ব্যবহারকারীর কাছ থেকে অ্যাপের ভাষা ইংরেজি বা বাংলা নির্বাচন করার সুযোগ দেয়। ব্যবহারকারী একটি ভাষা বেছে নিলে সেটি SharedPreferences এ সংরক্ষিত হয় এবং তারপর মূল অ্যাপ স্ক্রীন MainActivity শুরু হয়।