package com.example.carehive

import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MacronutrientsDistributionActivity : AppCompatActivity() {

    private lateinit var macronutrientsText: TextView
    private lateinit var macronutrientsInfo: TextView
    private lateinit var nextButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_macronutrients_distribution)

        macronutrientsText = findViewById(R.id.macronutrientsText)
        macronutrientsInfo = findViewById(R.id.macronutrientsInfo)
        nextButton = findViewById(R.id.nextButton)

        macronutrientsText.text = "Macronutrients Distribution"
        macronutrientsInfo.text = "Carbs: 50%\nProteins: 30%\nFats: 20%"

        nextButton.setOnClickListener {
            Toast.makeText(this, "Next button clicked", Toast.LENGTH_SHORT).show()
        }
    }
}
//MacronutrientsDistributionActivity হলো একটি স্ক্রিন যেটি ব্যবহারকারীকে দেখায় কীভাবে কার্বোহাইড্রেট, প্রোটিন এবং ফ্যাট খাদ্যতালিকায় বিতরণ করা উচিত। এটি একটি ইনফরমেশনাল স্ক্রিন যেখানে একটি বাটন রয়েছে এবং বাটন চাপলে একটি নোটিফিকেশন দেখায়।
