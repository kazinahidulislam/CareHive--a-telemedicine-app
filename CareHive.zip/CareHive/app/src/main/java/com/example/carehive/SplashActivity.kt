package com.example.carehive

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import android.widget.Button
import android.widget.Toast

import android.os.Handler
import android.os.Looper

class SplashActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash)

        val btnSelectLanguage: Button = findViewById(R.id.btnSelectLanguage)

        btnSelectLanguage.setOnClickListener {

            Toast.makeText(this, "Select Language Button Pressed", Toast.LENGTH_SHORT).show()

            val intent = Intent(this, LanguageSelectionActivity::class.java)
            startActivity(intent)
        }

        Handler(Looper.getMainLooper()).postDelayed({
            // Start the Language selection screen
            val intent = Intent(this, LanguageSelectionActivity::class.java)
            startActivity(intent)
            finish()
        }, 3000)
    }
}