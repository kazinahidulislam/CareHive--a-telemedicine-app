package com.example.carehive

import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import okhttp3.*
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import org.json.JSONException
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody
import okhttp3.MediaType
import okhttp3.Callback
import okhttp3.Response
import android.os.Handler
import android.os.Looper
import okhttp3.MediaType.Companion.toMediaType


class FindDoctorActivity : AppCompatActivity() {

    private lateinit var inputMessage: EditText
    private lateinit var sendMessageButton: Button
    private lateinit var chatbotResponse: TextView
    private val client = OkHttpClient()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_find_doctor)

        inputMessage = findViewById(R.id.inputMessage)
        sendMessageButton = findViewById(R.id.sendMessageButton)
        chatbotResponse = findViewById(R.id.chatbotResponse)

        sendMessageButton.setOnClickListener {
            val question = inputMessage.text.toString().trim()
            addMessageToChat(question, "me")
            inputMessage.text.clear()
            callAPI(question)
        }
    }

    private fun addMessageToChat(message: String, sentBy: String) {
        chatbotResponse.append("\n$sentBy: $message")
    }

    private fun callAPI(question: String) {
        val jsonBody = JSONObject()
        try {
            jsonBody.put("model", "gpt-3.5-turbo")
            val messages = JSONArray()
            val message = JSONObject()
            message.put("role", "user")
            message.put("content", question)
            messages.put(message)
            jsonBody.put("messages", messages)
            jsonBody.put("max_tokens", 1000)
            jsonBody.put("temperature", 0.7)
        } catch (e: JSONException) {
            e.printStackTrace()
        }

        val body = "application/json; charset=utf-8".toMediaType()
        val requestBody = RequestBody.create(body, jsonBody.toString())
        val request = Request.Builder()
            .url("https://api.openai.com/v1/chat/completions")
            .header("Authorization", "Bearer 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")
            .post(requestBody)
            .build()

        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                runOnUiThread {
                    chatbotResponse.append("\nError: ${e.message}")
                }
            }

            override fun onResponse(call: Call, response: Response) {
                if (response.isSuccessful) {
                    val jsonObject = JSONObject(response.body?.string())
                    val jsonArray = jsonObject.getJSONArray("choices")
                    val result = jsonArray.getJSONObject(0).getString("text")
                    runOnUiThread {
                        addMessageToChat(result.trim(), "bot")
                    }
                } else {
                    runOnUiThread {
                        chatbotResponse.append("\nError: ${response.body?.string()}")
                    }
                }
            }
        })

    }
}
//FindDoctorActivity ক্লাসটি একটি সহজ চ্যাটবট ইন্টারফেস তৈরি করে যেখানে ব্যবহারকারী প্রশ্ন করে এবং GPT-3.5-turbo API ব্যবহার করে উত্তর পায়। এটি প্রশ্ন পাঠায় OpenAI-এর API-তে এবং প্রাপ্ত উত্তর ইউজার ইন্টারফেসে দেখায়। এটি মূলত একটি ডাক্তারের তথ্য বা সাধারণ স্বাস্থ্য-সম্পর্কিত পরামর্শ জানতে ব্যবহার করা যেতে পারে, তবে API key-এর নিরাপত্তা নিশ্চিত করা আবশ্যক। যদিও API কাজ করছে নাহ।