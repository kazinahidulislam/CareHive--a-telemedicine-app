package com.example.carehive

import android.os.Bundle
import android.widget.CheckBox
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.example.carehive.R

class MealPlanningActivity : AppCompatActivity() {

    private lateinit var calorieText: TextView
    private lateinit var saturdayCheckBox: CheckBox
    private lateinit var sundayCheckBox: CheckBox
    private lateinit var mondayCheckBox: CheckBox
    private lateinit var tuesdayCheckBox: CheckBox
    private lateinit var wednesdayCheckBox: CheckBox
    private lateinit var thursdayCheckBox: CheckBox
    private lateinit var fridayCheckBox: CheckBox

    private var totalCalories = 0
    private val meals = mapOf(
        "Saturday" to MealPlan(
            "Breakfast: Oats & Fruits", 400,
            "Lunch: Brown Rice & Chicken", 500,
            "Snacks: Nuts & Yogurt", 300,
            "Dinner: Grilled Fish & Salad", 600
        ),
        "Sunday" to MealPlan(
            "Breakfast: Eggs & Toast", 350,
            "Lunch: Quinoa & Salmon", 450,
            "Snacks: Almonds & Banana", 300,
            "Dinner: Grilled Chicken & Veggies", 650
        ),
        "Monday" to MealPlan(
            "Breakfast: Oats & Fruits", 400,
            "Lunch: Brown Rice & Chicken", 500,
            "Snacks: Yogurt & Nuts", 280,
            "Dinner: Grilled Fish & Salad", 580
        ),
        "Tuesday" to MealPlan(
            "Breakfast: Smoothie Bowl", 420,
            "Lunch: Grilled Chicken Salad", 520,
            "Snacks: Apple & Peanut Butter", 270,
            "Dinner: Grilled Shrimp & Veggies", 600
        ),
        "Wednesday" to MealPlan(
            "Breakfast: Eggs & Toast", 380,
            "Lunch: Lentil Soup & Bread", 450,
            "Snacks: Carrot & Hummus", 200,
            "Dinner: Baked Salmon & Broccoli", 650
        ),
        "Thursday" to MealPlan(
            "Breakfast: Smoothie Bowl", 420,
            "Lunch: Quinoa & Salmon", 460,
            "Snacks: Greek Yogurt", 250,
            "Dinner: Grilled Chicken & Veggies", 590
        ),
        "Friday" to MealPlan(
            "Breakfast: Avocado Toast", 390,
            "Lunch: Brown Rice & Chicken", 510,
            "Snacks: Mixed Nuts", 280,
            "Dinner: Grilled Fish & Salad", 640
        )
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_meal_planning)

        initializeViews()
        setupCheckboxListeners()

        savedInstanceState?.let {
            totalCalories = it.getInt("TOTAL_CALORIES", 0)
            updateCalorieText()
        }
    }

    private fun initializeViews() {
        calorieText = findViewById(R.id.calorieText)

        saturdayCheckBox = findViewById(R.id.saturdayCheckBox)
        sundayCheckBox = findViewById(R.id.sundayCheckBox)
        mondayCheckBox = findViewById(R.id.mondayCheckBox)
        tuesdayCheckBox = findViewById(R.id.tuesdayCheckBox)
        wednesdayCheckBox = findViewById(R.id.wednesdayCheckBox)
        thursdayCheckBox = findViewById(R.id.thursdayCheckBox)
        fridayCheckBox = findViewById(R.id.fridayCheckBox)
    }

    private fun setupCheckboxListeners() {
        saturdayCheckBox.setOnCheckedChangeListener { _, isChecked -> updateCalories(isChecked, "Saturday") }
        sundayCheckBox.setOnCheckedChangeListener { _, isChecked -> updateCalories(isChecked, "Sunday") }
        mondayCheckBox.setOnCheckedChangeListener { _, isChecked -> updateCalories(isChecked, "Monday") }
        tuesdayCheckBox.setOnCheckedChangeListener { _, isChecked -> updateCalories(isChecked, "Tuesday") }
        wednesdayCheckBox.setOnCheckedChangeListener { _, isChecked -> updateCalories(isChecked, "Wednesday") }
        thursdayCheckBox.setOnCheckedChangeListener { _, isChecked -> updateCalories(isChecked, "Thursday") }
        fridayCheckBox.setOnCheckedChangeListener { _, isChecked -> updateCalories(isChecked, "Friday") }
    }

    private fun updateCalories(isChecked: Boolean, day: String) {
        val mealPlan = meals[day]
        val dayCalories = mealPlan?.totalCalories ?: 0

        totalCalories = if (isChecked) {
            totalCalories + dayCalories
        } else {
            totalCalories - dayCalories
        }

        updateCalorieText()
    }

    private fun updateCalorieText() {
        calorieText.text = "Total Calories: $totalCalories kcal"
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putInt("TOTAL_CALORIES", totalCalories)
    }

    data class MealPlan(
        val breakfast: String, val breakfastCalories: Int,
        val lunch: String, val lunchCalories: Int,
        val snacks: String, val snacksCalories: Int,
        val dinner: String, val dinnerCalories: Int
    ) {
        val totalCalories: Int
            get() = breakfastCalories + lunchCalories + snacksCalories + dinnerCalories
    }
}
//MealPlanningActivity একটি স্ক্রিন যা ব্যবহারকারীকে সপ্তাহের প্রতিটি দিনের জন্য খাবারের পরিকল্পনা ও মোট ক্যালরি হিসেব করার সুযোগ দেয়। প্রতিটি দিনের জন্য নির্দিষ্ট মেনু ও ক্যালরি যুক্ত আছে। ব্যবহারকারী একটি বা একাধিক দিন নির্বাচন করলে স্বয়ংক্রিয়ভাবে মোট ক্যালরি গণনা করে দেখানো হয়। এটি স্বাস্থ্য সচেতন ব্যবহারকারীদের জন্য কার্যকরী একটি ফিচার।