package com.example.carehive

data class MedicineAlarm(
    var documentId: String = "",
    val medicine_name: String = "",
    val medicine_type: String = "",
    val dose: String = "",
    val duration: String = "",
    val alarm_time: String = "",
    val time_of_day: String = ""
)
//MedicineAlarm হলো একটি ডেটা ক্লাস যা একটি ওষুধ খাওয়ার জন্য সেট করা অ্যালার্মের সমস্ত তথ্য নাম, ধরন, ডোজ, সময় ইত্যাদি ধারণ করে। এটি মূলত Firestore ডাটাবেজ থেকে ডেটা মডেল হিসেবে কাজ করে এবং ইউজারের অ্যালার্ম রিমাইন্ডার ফিচার বাস্তবায়নে ব্যবহৃত হয়।