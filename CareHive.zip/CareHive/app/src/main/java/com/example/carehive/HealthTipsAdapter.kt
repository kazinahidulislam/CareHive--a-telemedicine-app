package com.example.carehive

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class HealthTipsAdapter(private val context: Context, private val tipsList: List<String>) :
    RecyclerView.Adapter<HealthTipsAdapter.HealthTipViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): HealthTipViewHolder {
        val view = LayoutInflater.from(context).inflate(R.layout.item_health_tip, parent, false)
        return HealthTipViewHolder(view)
    }

    override fun onBindViewHolder(holder: HealthTipViewHolder, position: Int) {
        holder.tipTextView.text = tipsList[position]
    }

    override fun getItemCount(): Int {
        return tipsList.size
    }

    inner class HealthTipViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val tipTextView: TextView = itemView.findViewById(R.id.tipTextView)
    }
}
//HealthTipsAdapter হল একটি RecyclerView Adapter যা স্বাস্থ্য পরামর্শের লিস্ট দেখানোর জন্য ব্যবহৃত হয়। এটি প্রতিটি টিপস item_health_tip দেখিয়ে ব্যবহারকারীদের জন্য সহজবোধ্যভাবে তথ্য উপস্থাপন করে।