package com.example.carehive

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.card.MaterialCardView

class BalanceDietActivity : AppCompatActivity() {

    private lateinit var macronutrientsCard: MaterialCardView
    private lateinit var mealPlanningCard: MaterialCardView
    private lateinit var nutritionalInfoCard: MaterialCardView
    private lateinit var weightLossFoodsCard: MaterialCardView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_balance_diet)

        macronutrientsCard = findViewById(R.id.macronutrientsButton)
        mealPlanningCard = findViewById(R.id.mealPlanningButton)
        nutritionalInfoCard = findViewById(R.id.nutritionalInfoButton)
        weightLossFoodsCard = findViewById(R.id.weightLossFoodsButton)

        macronutrientsCard.setOnClickListener {
            val intent = Intent(this, MacronutrientsDistributionActivity::class.java)
            startActivity(intent)
        }

        mealPlanningCard.setOnClickListener {
            val intent = Intent(this, MealPlanningActivity::class.java)
            startActivity(intent)
        }

        nutritionalInfoCard.setOnClickListener {
            val intent = Intent(this, NutritionalInformationActivity::class.java)
            startActivity(intent)
        }

        weightLossFoodsCard.setOnClickListener {
            val intent = Intent(this, WeightLossFoodsListActivity::class.java)
            startActivity(intent)
        }
    }
}
//BalanceDietActivity হলো একটি Android Activity যা ইউজারকে চারটি স্বাস্থ্য বিষয়ক ফিচার ম্যাক্রোনিউট্রিয়েন্ট বণ্টন, মিল প্ল্যান, পুষ্টির তথ্য ও ওজন কমানোর খাবার অ্যাক্সেস করতে দেয়। প্রতিটি কার্ডে ক্লিক করলে ইউজার নতুন Activity তে চলে যায়, যা সংশ্লিষ্ট টপিকের বিস্তারিত তথ্য দেখায়। এটি ডায়েট ও নিউট্রিশন সচেতন ইউজারদের জন্য সহায়ক।