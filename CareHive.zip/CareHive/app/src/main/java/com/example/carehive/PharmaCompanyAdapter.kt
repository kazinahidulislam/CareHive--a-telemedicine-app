package com.example.carehive

import android.content.Intent
import android.net.Uri
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class PharmaCompanyAdapter(private val companies: List<PharmaCompany>) :
    RecyclerView.Adapter<PharmaCompanyAdapter.CompanyViewHolder>() {

    inner class CompanyViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val name: TextView = itemView.findViewById(R.id.companyName)
        val country: TextView = itemView.findViewById(R.id.companyCountry)
        val website: TextView = itemView.findViewById(R.id.companyWebsite)

        init {
            website.setOnClickListener {
                val company = companies[adapterPosition]
                val intent = Intent(Intent.ACTION_VIEW, Uri.parse(company.website))
                itemView.context.startActivity(intent)
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CompanyViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.pharma_company_item, parent, false)
        return CompanyViewHolder(view)
    }

    override fun onBindViewHolder(holder: CompanyViewHolder, position: Int) {
        val company = companies[position]
        holder.name.text = company.name
        holder.country.text = company.country
        holder.website.text = company.website
    }

    override fun getItemCount() = companies.size
}

data class PharmaCompany(
    val name: String,
    val country: String,
    val website: String
)
//PharmaCompanyAdapter একটি কাস্টম RecyclerView Adapter যা ওষুধ কোম্পানির নাম, দেশ ও ওয়েবসাইট তালিকা আকারে দেখায় এবং ওয়েবসাইটে ক্লিক করলে সেটি ব্রাউজারে খুলে। এটি UI-তে সহজে ডায়নামিক কোম্পানির তালিকা দেখানোর উপযোগী।