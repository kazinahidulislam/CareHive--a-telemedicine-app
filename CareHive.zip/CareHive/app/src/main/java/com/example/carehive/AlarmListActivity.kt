package com.example.carehive

import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.firestore.FirebaseFirestore

class AlarmListActivity : AppCompatActivity(), MedicineAlarmsAdapter.LoadAlarmsCallback {

    private lateinit var recyclerView: RecyclerView
    private lateinit var adapter: MedicineAlarmsAdapter
    private var alarmsList: MutableList<MedicineAlarm> = mutableListOf()

    private lateinit var db: FirebaseFirestore

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_alarm_list)

        db = FirebaseFirestore.getInstance()

        recyclerView = findViewById(R.id.recyclerView)
        adapter = MedicineAlarmsAdapter(this, alarmsList, this)

        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = adapter

        loadAlarms()
    }

    override fun onResume() {
        super.onResume()
        loadAlarms()
    }

    override fun loadAlarms() {
        db.collection("medicine_alarms")
            .get()
            .addOnSuccessListener { result ->
                alarmsList.clear()
                for (document in result) {
                    val alarm = document.toObject(MedicineAlarm::class.java).apply {
                        documentId = document.id
                    }
                    Log.d("AlarmDebug", "Loaded: $alarm")
                    alarmsList.add(alarm)
                }
                adapter.submitList(alarmsList.toList())
                Toast.makeText(this, "Loaded ${alarmsList.size} alarms", Toast.LENGTH_SHORT).show()
            }
            .addOnFailureListener { e ->
                Log.e("AlarmList", "Error loading alarms", e)
                Toast.makeText(this, "Error: ${e.message}", Toast.LENGTH_SHORT).show()
            }
    }
}


//AlarmListActivity হল একটি অ্যাক্টিভিটি যা Firebase Firestore থেকে medicine_alarms সংগ্রহ করে RecyclerView-তে দেখায়। এটি MedicineAlarmsAdapter ব্যবহার করে ডেটা দেখায় এবং প্রতিবার অ্যাক্টিভিটি শুরু বা আবার ফিরে এলে ডেটা refresh করে। এর ফলে সব অ্যালার্ম গুলো এক জায়গায় দেখতে পারে।