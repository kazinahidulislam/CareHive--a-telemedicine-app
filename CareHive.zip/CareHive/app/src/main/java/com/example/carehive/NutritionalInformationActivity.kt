package com.example.carehive

import android.os.Bundle
import android.widget.EditText
import android.widget.TextView
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity

class NutritionalInformationActivity : AppCompatActivity() {

    private lateinit var searchInput: EditText
    private lateinit var searchButton: Button
    private lateinit var resultText: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_nutritional_information)

        searchInput = findViewById(R.id.searchInput)
        searchButton = findViewById(R.id.searchButton)
        resultText = findViewById(R.id.resultText)

        searchButton.setOnClickListener {
            val foodItem = searchInput.text.toString()
            if (foodItem.isNotEmpty()) {
                resultText.text = getNutritionalInfo(foodItem)
            } else {
                resultText.text = "Please enter a food item."
            }
        }
    }

    private fun getNutritionalInfo(foodItem: String): String {
        return when (foodItem.lowercase()) {
            "apple" -> "Nutritional Info for $foodItem:\nCalories: 95\nProtein: 0.5g\nFat: 0.3g\nCarbs: 25g"
            "banana" -> "Nutritional Info for $foodItem:\nCalories: 105\nProtein: 1.3g\nFat: 0.4g\nCarbs: 27g"
            "chicken" -> "Nutritional Info for $foodItem:\nCalories: 335\nProtein: 30g\nFat: 25g\nCarbs: 0g"
            else -> "Nutritional Info for $foodItem:\nCalories: Unknown\nProtein: Unknown\nFat: Unknown\nCarbs: Unknown"
        }
    }
}

//NutritionalInformationActivity ব্যবহারকারীর দেওয়া খাবারের নাম অনুযায়ী পুষ্টি তথ্য দেখায়। এটি কয়েকটি নির্দিষ্ট খাবারের জন্য তথ্য সংরক্ষিত রেখেছে এবং বাকিদের জন্য Unknown রেজাল্ট দেখায়। ভবিষ্যতে এতে API বা ডেটাবেইস সংযোগ করে আরও অনেক খাবারের তথ্য যোগ করা যেতে পারে।
