package com.example.carehive

import android.content.Context
import android.content.res.Configuration
import java.util.*

object LanguageHelper {

    fun setLocale(context: Context, languageCode: String) {
        val locale = Locale(languageCode)
        Locale.setDefault(locale)
        val config = Configuration()
        config.setLocale(locale)
        context.resources.updateConfiguration(config, context.resources.displayMetrics)
    }
}
//LanguageHelper.kt ফাইলের setLocale() ফাংশন অ্যাপের ভাষা পরিবর্তনের দায়িত্ব পালন করে। এটি নির্দিষ্ট ভাষার কোড অনুযায়ী locale সেট করে এবং তা অ্যাপের রিসোর্স কনফিগারেশনে আপডেট করে, যার ফলে অ্যাপের UI সেই ভাষায় প্রদর্শিত হয়।