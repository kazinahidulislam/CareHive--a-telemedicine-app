package com.example.carehive

import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.example.carehive.databinding.ActivityIdealWeightCalculatorBinding
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

class IdealWeightCalculatorActivity : AppCompatActivity() {

    private lateinit var binding: ActivityIdealWeightCalculatorBinding
    private val genderOptions = arrayOf("Male", "Female")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityIdealWeightCalculatorBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupAutoCompleteTextView()
        setupClickListeners()
    }

    private fun setupAutoCompleteTextView() {
        // Create an ArrayAdapter for the gender options
        val adapter = ArrayAdapter(
            this,
            android.R.layout.simple_dropdown_item_1line, // Correct layout for AutoCompleteTextView
            genderOptions
        )
        binding.genderSpinner.setAdapter(adapter)

        // Manually trigger the dropdown to show when clicked
        binding.genderSpinner.setOnClickListener {
            binding.genderSpinner.showDropDown()
        }
    }

    private fun setupClickListeners() {
        // Handle calculate button click
        binding.calculateButton.setOnClickListener {
            validateAndCalculate()
        }
    }

    private fun validateAndCalculate() {
        val heightInput = binding.heightInput.text.toString()
        // Get the selected gender safely
        val selectedGender = binding.genderSpinner.text.toString().takeIf { it.isNotEmpty() } ?: "Male"

        when {
            heightInput.isEmpty() -> showError("Please enter your height")
            heightInput.toIntOrNull() == null -> showError("Invalid height format")
            heightInput.toInt() !in 50..300 -> showError("Height must be between 50-300 cm") // Reasonable range check
            else -> calculateIdealWeight(heightInput.toInt(), selectedGender)
        }
    }

    private fun calculateIdealWeight(heightCm: Int, gender: String) {
        lifecycleScope.launch {
            try {
                // Devine formula calculation for ideal weight
                val idealWeight = when (gender) {
                    "Male" -> calculateForMale(heightCm)
                    "Female" -> calculateForFemale(heightCm)
                    else -> throw IllegalArgumentException("Invalid gender")
                }

                val resultText = """
                    Your Ideal Weight:
                    ${idealWeight.first} kg - ${idealWeight.second} kg
                    (Based on $gender formula)
                """.trimIndent()

                binding.resultText.text = resultText
                binding.resultCard.visibility = android.view.View.VISIBLE

            } catch (e: Exception) {
                showError("Calculation failed: ${e.message}")
            }
        }
    }

    // Devine formula for calculating male ideal weight (with cm to inches conversion)
    private fun calculateForMale(heightCm: Int): Pair<Int, Int> {
        val heightInch = heightCm / 2.54
        val baseWeight = 50.0 + 2.3 * (heightInch - 60)
        val range = (baseWeight * 0.9).roundToInt() to (baseWeight * 1.1).roundToInt()
        return range
    }

    // Devine formula for calculating female ideal weight
    private fun calculateForFemale(heightCm: Int): Pair<Int, Int> {
        val heightInch = heightCm / 2.54
        val baseWeight = 45.5 + 2.3 * (heightInch - 60)
        val range = (baseWeight * 0.9).roundToInt() to (baseWeight * 1.1).roundToInt()
        return range
    }

    // Show error message in case of validation failure or exceptions
    private fun showError(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
        binding.resultCard.visibility = android.view.View.GONE
    }
}
