package com.example.carehive

import android.app.DatePickerDialog
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.firestore.FirebaseFirestore
import com.example.carehive.MedicineAdapter.MedicineActionListener
import java.text.SimpleDateFormat
import java.util.*

class MedicineInventoryActivity : AppCompatActivity(), MedicineActionListener {

    private lateinit var medicineNameEditText: EditText
    private lateinit var dosageEditText: EditText
    private lateinit var expiryDateEditText: EditText
    private lateinit var diseaseEditText: EditText
    private lateinit var saveButton: Button
    private lateinit var medicineRecyclerView: RecyclerView

    private val db = FirebaseFirestore.getInstance()
    private val medicineList = mutableListOf<Medicine>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_medicine_inventory)

        medicineNameEditText = findViewById(R.id.editTextMedicineName)
        dosageEditText = findViewById(R.id.editTextDosage)
        expiryDateEditText = findViewById(R.id.editTextExpiryDate)
        diseaseEditText = findViewById(R.id.editTextDisease)
        saveButton = findViewById(R.id.saveMedicineButton)
        medicineRecyclerView = findViewById(R.id.medicineListRecyclerView)

        medicineRecyclerView.layoutManager = LinearLayoutManager(this)
        val adapter = MedicineAdapter(medicineList, this)
        medicineRecyclerView.adapter = adapter

        loadMedicines()

        saveButton.setOnClickListener {
            if (validateDate(expiryDateEditText.text.toString())) {
                saveMedicineInfo(adapter)
            } else {
                Toast.makeText(this, "Invalid expiry date", Toast.LENGTH_SHORT).show()
            }
        }

        expiryDateEditText.setOnClickListener {
            showDatePickerDialog()
        }
    }

    private fun validateDate(dateString: String): Boolean {
        val dateFormat = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())
        dateFormat.isLenient = false

        try {
            dateFormat.parse(dateString)
        } catch (e: Exception) {
            return false
        }
        return true
    }

    fun loadMedicines() {
        db.collection("own_medicines")
            .get()
            .addOnSuccessListener { result ->
                medicineList.clear()
                for (document in result) {
                    val medicine = document.toObject(Medicine::class.java)
                    medicineList.add(medicine)
                }
                medicineRecyclerView.adapter?.notifyDataSetChanged()
            }
            .addOnFailureListener {
                Toast.makeText(this, "Error loading medicines", Toast.LENGTH_SHORT).show()
            }
    }

    private fun saveMedicineInfo(adapter: MedicineAdapter) {
        val medicineName = medicineNameEditText.text.toString().trim()
        val dosage = dosageEditText.text.toString().trim()
        val expiryDate = expiryDateEditText.text.toString().trim()
        val disease = diseaseEditText.text.toString().trim()

        if (medicineName.isEmpty() || dosage.isEmpty() || expiryDate.isEmpty() || disease.isEmpty()) {
            Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show()
            return
        }

        val newDocumentRef = db.collection("own_medicines").document()
        val newMedicine = Medicine(newDocumentRef.id, medicineName, dosage, expiryDate, disease)

        newDocumentRef.set(newMedicine)

        Toast.makeText(this, "Medicine saved successfully", Toast.LENGTH_SHORT).show()
        loadMedicines()
    }

    override fun onUpdateClick(medicine: Medicine) {
        val updatedData: MutableMap<String, Any> = hashMapOf(
            "medicineName" to medicine.medicineName,
            "dosage" to medicine.dosage,
            "expiryDate" to medicine.expiryDate,
            "disease" to medicine.disease
        )

        if (medicine.id.isNotEmpty()) {
            db.collection("own_medicines")
                .document(medicine.id)
                .update(updatedData)
                .addOnSuccessListener {
                    Toast.makeText(this, "Medicine updated", Toast.LENGTH_SHORT).show()
                    loadMedicines()
                }
                .addOnFailureListener {
                    Toast.makeText(this, "Error updating medicine", Toast.LENGTH_SHORT).show()
                }
        } else {
            Toast.makeText(this, "Invalid medicine ID", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onDeleteClick(medicine: Medicine) {

        if (medicine.id.isNotEmpty()) {
            db.collection("own_medicines")
                .document(medicine.id)
                .delete()
                .addOnSuccessListener {
                    Toast.makeText(this, "Medicine deleted", Toast.LENGTH_SHORT).show()
                    loadMedicines()
                }
                .addOnFailureListener {
                    Toast.makeText(this, "Error deleting medicine", Toast.LENGTH_SHORT).show()
                }
        } else {
            Toast.makeText(this, "Invalid medicine ID", Toast.LENGTH_SHORT).show()
        }
    }

    private fun showDatePickerDialog() {
        val calendar = Calendar.getInstance()
        val year = calendar.get(Calendar.YEAR)
        val month = calendar.get(Calendar.MONTH)
        val day = calendar.get(Calendar.DAY_OF_MONTH)

        val datePickerDialog = DatePickerDialog(
            this,
            { _, selectedYear, selectedMonth, selectedDay ->

                val formattedDate = String.format(
                    Locale.getDefault(),
                    "%02d/%02d/%04d",
                    selectedDay,
                    selectedMonth + 1,
                    selectedYear
                )
                expiryDateEditText.setText(formattedDate)
            },
            year,
            month,
            day
        )
        datePickerDialog.show()
    }
}

//MedicineInventoryActivity একটি Activity যা ওষুধের নাম, ডোজ, মেয়াদ শেষের তারিখ ও রোগ অনুযায়ী Firebase Firestore-এ ওষুধ সংরক্ষণ, দেখানো, আপডেট এবং ডিলিট করার কাজ করে। এটি ব্যবহারকারীকে একটি DatePicker দিয়ে তারিখ নির্বাচন এবং RecyclerView দিয়ে ওষুধ তালিকা দেখায়।
