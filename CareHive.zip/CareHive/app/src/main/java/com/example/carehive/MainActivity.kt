package com.example.carehive

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.net.ConnectivityManager
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.cardview.widget.CardView
import com.google.android.material.card.MaterialCardView
import com.google.android.material.switchmaterial.SwitchMaterial
import java.util.Locale

class MainActivity : AppCompatActivity() {

    // ভিউগুলো ডিক্লেয়ারেশন
    private lateinit var btnFindMedicine: CardView
    private lateinit var btnFindDoctor: CardView
    private lateinit var btnHealthCalculator: CardView
    private lateinit var btnBalancedDiet: CardView
    private lateinit var btnProfile: MaterialCardView   // MaterialCardView, কারণ XML-এ এটা MaterialCardView
    private lateinit var btnOwnMedicine: CardView
    private lateinit var costOfDoctorButton: CardView
    private lateinit var healthTipsButton: CardView
    private lateinit var medicineAlarmButton: CardView
    private lateinit var darkModeSwitch: SwitchMaterial

    // ** নতুন btnSearchCure যুক্ত করলাম **
    private lateinit var btnSearchCure: CardView

    private lateinit var sharedPref: SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // SharedPreferences ইনিশিয়ালাইজ এবং থিম প্রয়োগ করা (ContentView এর আগে)
        sharedPref = getSharedPreferences("AppSettings", MODE_PRIVATE)
        applyTheme()

        setContentView(R.layout.activity_main)

        // ভিউ ইনিশিয়ালাইজেশন
        btnFindMedicine = findViewById(R.id.btnFindMedicine)
        btnFindDoctor = findViewById(R.id.btnFindDoctor)
        btnHealthCalculator = findViewById(R.id.btnHealthCalculator)
        btnBalancedDiet = findViewById(R.id.btnBalancedDiet)
        btnProfile = findViewById(R.id.profileButton)   // MaterialCardView
        btnOwnMedicine = findViewById(R.id.btnOwnMedicine)
        costOfDoctorButton = findViewById(R.id.costOfDoctorButton)
        healthTipsButton = findViewById(R.id.healthTipsButton)
        medicineAlarmButton = findViewById(R.id.medicineAlarmButton)
        darkModeSwitch = findViewById(R.id.darkModeSwitch)

        // ** নতুন btnSearchCure এর ইনিশিয়ালাইজেশন **
        btnSearchCure = findViewById(R.id.btnSearchCure)

        // AI Help বাটনের সেটআপ
        setupAIHelpButton()

        // বিভিন্ন বাটনে ক্লিক লিসেনার সেটআপ
        medicineAlarmButton.setOnClickListener {
            startActivity(Intent(this, MedicineAlarmActivity::class.java))
        }

        btnHealthCalculator.setOnClickListener {
            startActivity(Intent(this, HealthCalculatorActivity::class.java))
        }

        btnBalancedDiet.setOnClickListener {
            startActivity(Intent(this, BalanceDietActivity::class.java))
        }

        btnFindMedicine.setOnClickListener {
            startActivity(Intent(this, FindMedicineActivity::class.java))
        }

        btnFindDoctor.setOnClickListener {
            startActivity(Intent(this, FindDoctorActivity::class.java))
        }

        btnOwnMedicine.setOnClickListener {
            try {
                startActivity(Intent(this, MedicineInventoryActivity::class.java))
            } catch (e: Exception) {
                Log.e("IntentError", "Error starting MedicineInventoryActivity", e)
                Toast.makeText(this, "Error opening Medicine Inventory", Toast.LENGTH_SHORT).show()
            }
        }

        costOfDoctorButton.setOnClickListener {
            startActivity(Intent(this, DoctorSearchActivity::class.java))
        }

        healthTipsButton.setOnClickListener {
            val intent = Intent(this, HealthTipsActivity::class.java)
            intent.putExtra("CATEGORY", "mental_health")
            startActivity(intent)
        }

        btnProfile.setOnClickListener {
            val intent = Intent(this, ProfileActivity::class.java)
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(intent)
            finish()
        }

        // ** নতুন Search & Cure বাটনের ক্লিক লিসেনার **
        btnSearchCure.setOnClickListener {
            startActivity(Intent(this, DiseaseSearchActivity::class.java))
        }

        // Dark Mode Switch সেটআপ
        setupDarkModeSwitch()

        // ভাষা সেটআপ
        setLanguage()
    }

    // থিম প্রয়োগ ফাংশন
    private fun applyTheme() {
        if (sharedPref.getBoolean("dark_mode", false)) {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
        } else {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
        }
    }

    // Dark Mode Switch সেটআপ
    private fun setupDarkModeSwitch() {
        val isDarkMode = sharedPref.getBoolean("dark_mode", false)
        darkModeSwitch.isChecked = isDarkMode

        darkModeSwitch.setOnCheckedChangeListener { _, isChecked ->
            sharedPref.edit().putBoolean("dark_mode", isChecked).apply()
            AppCompatDelegate.setDefaultNightMode(
                if (isChecked) AppCompatDelegate.MODE_NIGHT_YES else AppCompatDelegate.MODE_NIGHT_NO
            )
        }
    }

    // ভাষা সেটআপ ফাংশন
    private fun setLanguage() {
        val langPref = getSharedPreferences("LanguagePrefs", MODE_PRIVATE)
        val selectedLanguage = langPref.getString("selected_language", "en") ?: "en"

        val locale = Locale(selectedLanguage)
        Locale.setDefault(locale)
        val config = resources.configuration
        config.setLocale(locale)
        resources.updateConfiguration(config, resources.displayMetrics)

        findViewById<TextView>(R.id.app_name).text = getString(R.string.app_name)
    }

    // ইন্টারনেট চেক ফাংশন
    private fun isInternetAvailable(): Boolean {
        val connectivityManager = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        return connectivityManager.activeNetworkInfo?.isConnected == true
    }

    // AI Help বাটনের ক্লিক হ্যান্ডলার সেটআপ
    private fun setupAIHelpButton() {
        val btnHelpAI = findViewById<CardView>(R.id.btnHelpAI)
        btnHelpAI.setOnClickListener {
            showAIHelpDialog()
        }
    }

    // AI Help ডায়ালগ শো করার ফাংশন
    private fun showAIHelpDialog() {
        val options = arrayOf("ChatGPT", "Deepseek")
        AlertDialog.Builder(this)
            .setTitle("Choose AI Service")
            .setItems(options) { _, which ->
                when (which) {
                    0 -> openWebPage("https://chat.openai.com")
                    1 -> openWebPage("https://www.deepseek.com")
                }
            }
            .show()
    }

    // ওয়েবপেজ ওপেন করার ফাংশন
    private fun openWebPage(url: String) {
        if (isInternetAvailable()) {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
            startActivity(intent)
        } else {
            Toast.makeText(this, "Please turn on your internet connection", Toast.LENGTH_LONG).show()
        }
    }

    // থিম চেক করার জন্য onResume এ থিম প্রয়োগ (ঐচ্ছিক)
    override fun onResume() {
        super.onResume()
        val isDarkMode = sharedPref.getBoolean("dark_mode", false)
        if (isDarkMode) {
            setTheme(R.style.Theme_CareHive_Dark)
        } else {
            setTheme(R.style.Theme_CareHive)
        }
    }

    // কনফিগারেশন চেঞ্জ হ্যান্ডল (ঐচ্ছিক)
    override fun onConfigurationChanged(newConfig: android.content.res.Configuration) {
        super.onConfigurationChanged(newConfig)
        // প্রয়োজন হলে এখানে হ্যান্ডেল করুন
    }
}
