package com.example.carehive

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.carehive.databinding.ActivityPharmaCompaniesBinding

class PharmaCompaniesActivity : AppCompatActivity() {

    private lateinit var binding: ActivityPharmaCompaniesBinding
    private lateinit var adapter: PharmaCompanyAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityPharmaCompaniesBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val companies = listOf(
            PharmaCompany("Square Pharmaceuticals", "Bangladesh", "https://www.squarepharma.com.bd"),
            PharmaCompany("Beximco Pharmaceuticals", "Bangladesh", "https://www.beximcopharma.com"),
            PharmaCompany("Incepta Pharmaceuticals", "Bangladesh", "https://www.inceptapharma.com"),
            PharmaCompany("Novartis", "Switzerland", "https://www.novartis.com"),
            PharmaCompany("Pfizer", "USA", "https://www.pfizer.com")
        )
        adapter = PharmaCompanyAdapter(companies)
        binding.pharmaRecyclerView.layoutManager = LinearLayoutManager(this)
        binding.pharmaRecyclerView.adapter = adapter
    }
}
//PharmaCompaniesActivity একটি সহজ লিস্ট আকারে কিছু আন্তর্জাতিক ও স্থানীয় ফার্মাসিউটিক্যাল কোম্পানির নাম, অবস্থান এবং ওয়েবসাইট দেখায় RecyclerView-এর মাধ্যমে। ViewBinding এবং Adapter ব্যবহারের মাধ্যমে Activity-টি কোডকে পরিচ্ছন্ন ও কার্যকরভাবে উপস্থাপন করে।