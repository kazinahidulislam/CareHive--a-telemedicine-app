package com.example.carehive

import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.firestore.FirebaseFirestore

class MedicineAlarmsAdapter(
    private val context: Context,
    private var alarmsList: MutableList<MedicineAlarm>,
    private val callback: LoadAlarmsCallback
) : RecyclerView.Adapter<MedicineAlarmsAdapter.MedicineAlarmViewHolder>() {

    interface LoadAlarmsCallback {
        fun loadAlarms()
    }

    private fun deleteAlarm(documentId: String) {
        val db = FirebaseFirestore.getInstance()
        db.collection("medicine_alarms").document(documentId)
            .delete()
            .addOnSuccessListener {
                Toast.makeText(context, "Alarm Deleted", Toast.LENGTH_SHORT).show()
                callback.loadAlarms()
            }
            .addOnFailureListener { e ->
                Toast.makeText(context, "Error deleting alarm: ${e.message}", Toast.LENGTH_SHORT).show()
            }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MedicineAlarmViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_alarm, parent, false)
        return MedicineAlarmViewHolder(view)
    }

    override fun onBindViewHolder(holder: MedicineAlarmViewHolder, position: Int) {
        holder.bind(alarmsList[position])
    }

    override fun getItemCount(): Int = alarmsList.size

    fun submitList(newList: List<MedicineAlarm>) {
        alarmsList.clear()
        alarmsList.addAll(newList)
        notifyDataSetChanged()
    }

    inner class MedicineAlarmViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {

        private val editButton: Button = itemView.findViewById(R.id.editButton)
        private val deleteButton: Button = itemView.findViewById(R.id.deleteButton)

        fun bind(alarm: MedicineAlarm) {
            itemView.apply {
                findViewById<TextView>(R.id.medicineName).text = alarm.medicine_name
                findViewById<TextView>(R.id.dose).text = "ডোজ: ${alarm.dose}"
                findViewById<TextView>(R.id.duration).text = "সময়কাল: ${alarm.duration}"
                findViewById<TextView>(R.id.time).text = "সময়: ${alarm.alarm_time} (${alarm.time_of_day})"
            }

            editButton.setOnClickListener {
                val intent = Intent(itemView.context, EditMedicineAlarmActivity::class.java)
                intent.putExtra("ALARM_ID", alarm.documentId)
                itemView.context.startActivity(intent)
            }

            deleteButton.setOnClickListener {
                deleteAlarm(alarm.documentId)
            }
        }
    }
}
//MedicineAlarmsAdapter হল RecyclerView-এর জন্য একটি কাস্টম অ্যাডাপ্টার যা MedicineAlarm তালিকা প্রদর্শন, সম্পাদনা ও মুছে ফেলার সুযোগ দেয়। এটি Firestore থেকে অ্যালার্ম ডিলিট করে এবং Edit ক্লিকে সম্পাদনা পেইজে নিয়ে যায়। প্রতিটি তালিকার জন্য ডেটা bind করে এবং UI আপডেট করে।