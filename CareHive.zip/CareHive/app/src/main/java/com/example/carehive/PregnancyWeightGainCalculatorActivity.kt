package com.example.carehive

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.widget.addTextChangedListener
import com.example.carehive.databinding.ActivityPregnancyWeightGainCalculatorBinding
import java.text.NumberFormat

class PregnancyWeightGainCalculatorActivity : AppCompatActivity() {

    private lateinit var binding: ActivityPregnancyWeightGainCalculatorBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPregnancyWeightGainCalculatorBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupInputValidation()
        setupClickListeners()
    }

    private fun setupInputValidation() {
        binding.pregnancyWeeksInput.addTextChangedListener {
            val inputLength = it?.length ?: 0
            if (inputLength > 2) {
                binding.pregnancyWeeksInput.error = "Maximum 40 weeks"
            }
        }
    }

    private fun setupClickListeners() {
        binding.calculateButton.setOnClickListener {
            validateAndCalculate()
        }
    }

    private fun validateAndCalculate() {
        val weeksInput = binding.pregnancyWeeksInput.text.toString()

        when {
            weeksInput.isEmpty() -> showError("Please enter pregnancy weeks")
            weeksInput.toIntOrNull() == null -> showError("Invalid number format")
            weeksInput.toInt() !in 1..40 -> showError("Valid range: 1-40 weeks")
            else -> showWeightGainResult(weeksInput.toInt())
        }
    }

    private fun showWeightGainResult(weeks: Int) {
        val recommendation = calculatePregnancyWeightGain(weeks)

        val formattedWeightRange = "${NumberFormat.getInstance().format(recommendation.weightRange.start)} - ${NumberFormat.getInstance().format(recommendation.weightRange.endInclusive)} kg"

        binding.resultText.text = getString(
            R.string.weight_gain_result,
            formattedWeightRange,
            recommendation.trimester,
            recommendation.additionalInfo
        )

        binding.resultCard.visibility = android.view.View.VISIBLE
    }

    private fun calculatePregnancyWeightGain(weeks: Int): PregnancyWeightRecommendation {
        return when {
            weeks <= 13 -> PregnancyWeightRecommendation(
                weightRange = (1.5..2.5).perWeek(weeks),
                trimester = "1st Trimester",
                additionalInfo = "Focus on nutrient-rich foods"
            )
            weeks in 14..26 -> PregnancyWeightRecommendation(
                weightRange = (0.5..0.7).perWeek(weeks),
                trimester = "2nd Trimester",
                additionalInfo = "Steady weight gain recommended"
            )
            weeks in 27..40 -> PregnancyWeightRecommendation(
                weightRange = (0.5..1.0).perWeek(weeks),
                trimester = "3rd Trimester",
                additionalInfo = "Monitor weight regularly"
            )
            else -> PregnancyWeightRecommendation(
                weightRange = 0.0..0.0,
                trimester = "Post-term",
                additionalInfo = "Consult your healthcare provider"
            )
        }
    }


    private fun showError(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
        binding.resultCard.visibility = android.view.View.GONE
    }

    data class PregnancyWeightRecommendation(
        val weightRange: ClosedFloatingPointRange<Double>,
        val trimester: String,
        val additionalInfo: String
    )

    private infix fun ClosedFloatingPointRange<Double>.perWeek(weeks: Int): ClosedFloatingPointRange<Double> {
        return this.start * weeks..this.endInclusive * weeks
    }
}
//এই Activity টি গর্ভাবস্থায় কত কেজি ওজন বাড়া উচিত তা সপ্তাহ অনুসারে নির্ণয় করে দেখায়। ইউজার সপ্তাহ ইনপুট দিলে অ্যাপটি সেই অনুযায়ী ট্রাইমেস্টার অনুযায়ী ওজন রেঞ্জ ও পরামর্শ দেখায় (যেমন nutrient-rich foods বা monitor weight)। Validation ও ফরম্যাটিংসহ উন্নত UI ব্যবহার করা হয়েছে।