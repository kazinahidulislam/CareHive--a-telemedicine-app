package com.example.carehive

import android.os.Bundle
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import android.content.Context
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.firestore.FirebaseFirestore
import com.google.android.material.textfield.TextInputEditText
import android.text.Editable
import android.text.TextWatcher

class FindMedicineActivity : AppCompatActivity() {

    private lateinit var resultTextView: TextView
    private lateinit var searchEditText: TextInputEditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_find_medicine)

        searchEditText = findViewById(R.id.searchEditText)
        resultTextView = findViewById(R.id.resultTextView)

        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.showSoftInput(searchEditText, InputMethodManager.SHOW_IMPLICIT)

        val searchButton: Button = findViewById(R.id.searchButton)
        searchButton.setOnClickListener {
            val medicineName = searchEditText.text.toString().trim()
            if (medicineName.isNotEmpty()) {
                fetchMedicineInfo(medicineName)
            } else {
                Toast.makeText(this, getString(R.string.enter_medicine_name_message), Toast.LENGTH_SHORT).show()
            }
        }

        searchEditText.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(charSequence: CharSequence?, start: Int, count: Int, after: Int) {}

            override fun onTextChanged(charSequence: CharSequence?, start: Int, before: Int, count: Int) {
                val searchQuery = charSequence.toString()
                if (searchQuery.isEmpty()) {
                    resultTextView.visibility = View.VISIBLE
                    resultTextView.text = getString(R.string.no_results_found)
                } else {
                    resultTextView.visibility = View.VISIBLE
                }
            }

            override fun afterTextChanged(editable: Editable?) {}
        })
    }

    private fun fetchMedicineInfo(medicineName: String) {
        val db = FirebaseFirestore.getInstance()
        val medicinesRef = db.collection("medicines")

        val medicineNameLower = medicineName.lowercase()

        val query = medicinesRef.whereEqualTo("name_lowercase", medicineNameLower)

        query.get().addOnSuccessListener { snapshot ->
            if (snapshot != null && !snapshot.isEmpty) {
                val document = snapshot.documents[0]
                val company = document.getString("company") ?: "N/A"
                val disease = document.getString("disease") ?: "N/A"
                val price = document.getString("price") ?: "N/A"

                resultTextView.text = "Company: $company\nDisease: $disease\nPrice: $price"
            } else {
                resultTextView.text = getString(R.string.no_result_found_for, medicineName)
            }
        }.addOnFailureListener { exception ->
            resultTextView.text = getString(R.string.failed_to_load_data)
            Log.e("FirebaseError", "Failed to fetch data", exception)
        }
    }
}
