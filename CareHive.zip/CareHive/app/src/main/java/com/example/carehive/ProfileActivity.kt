package com.example.carehive

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity

class ProfileActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profile)

        val btnUserRegistration = findViewById<Button>(R.id.btnUserRegistration)
        val btnPharmaCompanies = findViewById<Button>(R.id.btnPharmaCompanies)
        val btnAbout = findViewById<Button>(R.id.btnAbout)

        btnUserRegistration.setOnClickListener {
            val intent = Intent(this, UserRegistrationActivity::class.java)
            startActivity(intent)
        }

        btnPharmaCompanies.setOnClickListener {
            val intent = Intent(this, PharmaCompaniesActivity::class.java)
            startActivity(intent)
        }

        btnAbout.setOnClickListener {
            val intent = Intent(this, AboutActivity::class.java)
            startActivity(intent)
        }
    }
}
//এই ProfileActivity-তে তিনটি বোতাম রয়েছে: ইউজার রেজিস্ট্রেশন, ফার্মা কোম্পানি এবং অ্যাপ সম্পর্কিত তথ্য। প্রতিটি বোতামে ক্লিক করলে সংশ্লিষ্ট Activity তে নিয়ে যায়। এটি অ্যাপের একটি ন্যাভিগেশনাল মেনু হিসেবে কাজ করে।
