package com.example.carehive

import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.AutoCompleteTextView
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.textfield.TextInputLayout
import com.google.firebase.firestore.FirebaseFirestore

class HealthTipsActivity : AppCompatActivity() {

    private lateinit var tipsRecyclerView: RecyclerView
    private lateinit var tipsAdapter: HealthTipsAdapter
    private lateinit var categoryAutoComplete: AutoCompleteTextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_health_tips)

        tipsRecyclerView = findViewById(R.id.healthTipsRecyclerView)

        val categoryTextInputLayout = findViewById<TextInputLayout>(R.id.category)
        categoryAutoComplete = categoryTextInputLayout.editText as AutoCompleteTextView

        val searchButton: Button = findViewById(R.id.searchButton)

        val healthTipsList = mutableListOf<String>()
        val db = FirebaseFirestore.getInstance()

        val categories = listOf("mental_health", "physical_health", "nutrition_tips")
        val categoryAdapter = ArrayAdapter(this, android.R.layout.simple_dropdown_item_1line, categories)
        categoryAutoComplete.setAdapter(categoryAdapter)

        searchButton.setOnClickListener {
            val selectedCategory = categoryAutoComplete.text.toString()
            if (selectedCategory.isNotEmpty()) {
                fetchHealthTips(db, selectedCategory, healthTipsList)
            } else {
                Toast.makeText(this, "Please select a category", Toast.LENGTH_SHORT).show()
            }
        }

        tipsRecyclerView.layoutManager = LinearLayoutManager(this)
    }

    private fun fetchHealthTips(db: FirebaseFirestore, category: String, healthTipsList: MutableList<String>) {
        db.collection("health_tips_categories")
            .document(category)
            .get()
            .addOnSuccessListener { document ->
                val tips = document.get("tips") as? List<String>
                tips?.let {
                    healthTipsList.clear()
                    healthTipsList.addAll(it)
                    tipsAdapter = HealthTipsAdapter(this, healthTipsList)
                    tipsRecyclerView.adapter = tipsAdapter
                }
            }
            .addOnFailureListener { exception ->
                Toast.makeText(this, "Failed to load tips: ${exception.message}", Toast.LENGTH_SHORT).show()
            }
    }
}
//HealthTipsActivity ব্যবহারকারীকে তিনটি ক্যাটাগরির (মানসিক স্বাস্থ্য, শারীরিক স্বাস্থ্য, পুষ্টি) মধ্যে একটি নির্বাচন করে সেই ক্যাটাগরির স্বাস্থ্য টিপস দেখতে দেয়। Firebase Firestore থেকে টিপস পড়ে RecyclerView-তে দেখানো হয়। এটি ব্যবহারকারীদের সঠিক ও প্রয়োজনীয় স্বাস্থ্য পরামর্শ জানতে সহায়তা করে। 