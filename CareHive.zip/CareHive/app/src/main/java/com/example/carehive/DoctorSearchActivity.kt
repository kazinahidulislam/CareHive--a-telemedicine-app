package com.example.carehive

import android.os.Bundle
import android.util.Log
import android.widget.ArrayAdapter
import android.widget.AutoCompleteTextView
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.textfield.TextInputLayout
import com.google.firebase.firestore.FirebaseFirestore

class DoctorSearchActivity : AppCompatActivity() {

    private lateinit var specializationTextInputLayout: TextInputLayout
    private lateinit var doctorRecyclerView: RecyclerView
    private lateinit var searchButton: Button
    private val db = FirebaseFirestore.getInstance()
    private val doctorList = mutableListOf<Doctor>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_doctor_search)

        specializationTextInputLayout = findViewById(R.id.specializationSpinner)
        doctorRecyclerView = findViewById(R.id.doctorRecyclerView)
        searchButton = findViewById(R.id.searchButton)


        val specializationAutoCompleteTextView = specializationTextInputLayout.editText as AutoCompleteTextView

        val specializationList = listOf("Gynecology", "Dental", "Cardiology", "Pediatrics")
        val adapter = ArrayAdapter(this, android.R.layout.simple_dropdown_item_1line, specializationList)
        specializationAutoCompleteTextView.setAdapter(adapter)

        doctorRecyclerView.layoutManager = LinearLayoutManager(this)

        searchButton.setOnClickListener {
            val selectedSpecialization = specializationAutoCompleteTextView.text.toString()
            if (selectedSpecialization.isNotEmpty()) {
                searchDoctorsBySpecialization(selectedSpecialization)
            } else {
                Toast.makeText(this, "Please select a specialization", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun searchDoctorsBySpecialization(specialization: String) {
        db.collection("doctors")
            .whereEqualTo("specialization", specialization)
            .get()
            .addOnSuccessListener { result ->
                doctorList.clear()
                for (document in result) {
                    val testsFee = document.get("consultationFee.tests") as? Double ?: 0.0
                    val generalConsultationFee = document.get("consultationFee.generalConsultation") as? Double ?: 0.0
                    val surgeryFee = document.get("consultationFee.surgery") as? Double ?: 0.0

                    Log.d("DoctorSearch", "testsFee: $testsFee, generalConsultationFee: $generalConsultationFee, surgeryFee: $surgeryFee")

                    val doctor = document.toObject(Doctor::class.java)

                    doctor.consultationFee = mapOf(
                        "tests" to testsFee,
                        "generalConsultation" to generalConsultationFee,
                        "surgery" to surgeryFee
                    )

                    doctorList.add(doctor)
                }

                val adapter = DoctorAdapter(doctorList)
                doctorRecyclerView.adapter = adapter
            }
            .addOnFailureListener {
                Toast.makeText(this, "Error loading doctors", Toast.LENGTH_SHORT).show()
            }
    }
}
//DoctorSearchActivity হল CareHive অ্যাপের এমন একটি ফিচার যেখানে ব্যবহারকারী নির্দিষ্ট Specialization অনুযায়ী ডাক্তার খুঁজে পেতে পারেন। এটি AutoCompleteTextView দিয়ে সিলেকশন নিতে পারে এবং Firebase Firestore থেকে ডাক্তারদের ডেটা এনে RecyclerView তে দেখায়। এই স্ক্রিনটি ব্যবহারকারীদের দ্রুত এবং সহজে তাদের প্রয়োজন অনুযায়ী ডাক্তার খুঁজে পেতে সহায়তা করে।