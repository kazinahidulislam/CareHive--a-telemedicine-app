package com.example.carehive

import android.os.Bundle
import android.util.Log
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.Spinner
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class BMRCalculatorActivity : AppCompatActivity() {

    private lateinit var weightInput: EditText
    private lateinit var heightInput: EditText
    private lateinit var ageInput: EditText
    private lateinit var genderSpinner: Spinner
    private lateinit var calculateButton: Button
    private lateinit var resultText: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_bmr_calculator)

        weightInput = findViewById(R.id.weightInput)
        heightInput = findViewById(R.id.heightInput)
        ageInput = findViewById(R.id.ageInput)
        genderSpinner = findViewById(R.id.genderSpinner)
        calculateButton = findViewById(R.id.calculateButton)
        resultText = findViewById(R.id.resultText)

        val genderOptions = resources.getStringArray(R.array.gender_array)
        val genderAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, genderOptions)
        genderAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        genderSpinner.adapter = genderAdapter

        genderSpinner.setOnItemSelectedListener(object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: android.view.View?, position: Int, id: Long) {
                val selectedGender = parent?.getItemAtPosition(position).toString()
                Log.d("GenderSpinner", "Selected: $selectedGender")
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {
                Log.d("GenderSpinner", "No gender selected")
            }
        })

        calculateButton.setOnClickListener {
            val weight = weightInput.text.toString().toFloatOrNull()
            val height = heightInput.text.toString().toFloatOrNull()
            val age = ageInput.text.toString().toIntOrNull()
            val gender = genderSpinner.selectedItem.toString()

            if (weight != null && height != null && age != null) {
                val bmr = calculateBMR(weight, height, age, gender)
                resultText.text = "Your BMR: $bmr kcal/day"
            } else {
                resultText.text = "Please enter valid values."
            }
        }
    }

    private fun calculateBMR(weight: Float, height: Float, age: Int, gender: String): Float {
        return if (gender == "Male") {
            (88.362 + (13.397 * weight) + (4.799 * height) - (5.677 * age)).toFloat()
        } else {
            (447.593 + (9.247 * weight) + (3.098 * height) - (4.330 * age)).toFloat()
        }
    }
}
