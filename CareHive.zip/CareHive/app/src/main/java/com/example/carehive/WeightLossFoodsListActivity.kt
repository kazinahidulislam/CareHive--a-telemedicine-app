package com.example.carehive

import android.os.Bundle
import android.widget.TextView
import android.widget.ScrollView
import androidx.appcompat.app.AppCompatActivity

class WeightLossFoodsListActivity : AppCompatActivity() {

    private lateinit var weightLossFoodsText: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_weight_loss_foods_list)

        weightLossFoodsText = findViewById(R.id.weightLossFoodsText)

        weightLossFoodsText.text = """
            Weight Loss Foods List:

            1. Green Leafy Vegetables:
               Rich in fiber and low in calories. Great for metabolism and overall health.

            2. Whole Grains:
               Packed with nutrients and fiber, whole grains help in controlling hunger and provide sustained energy.

            3. Lean Proteins:
               Foods like chicken breast, fish, and tofu provide essential proteins to maintain muscle mass while losing fat.

            4. Legumes:
               Beans, lentils, and chickpeas are great sources of fiber and protein, making them perfect for a weight-loss diet.

            5. Nuts & Seeds:
               Healthy fats in nuts and seeds can help curb hunger while providing essential nutrients.

            Tip: Pair these foods with a balanced exercise routine for optimal weight loss!
        """
    }
}
//WeightLossFoodsListActivity একটি সহজ অ্যাক্টিভিটি যা TextView-র মাধ্যমে ইউজারকে ওজন কমাতে সাহায্যকারী খাদ্য তালিকা দেখায়। তালিকায় ৫টি স্বাস্থ্যকর খাবারের ধরন এবং একটি ব্যায়ামের পরামর্শ অন্তর্ভুক্ত আছে। এটি UI ও তথ্য উপস্থাপনার একটি সহজ উদাহরণ।
